f a = a/2

g a = a-1
compose  a= f(g(a))

main = print $ compose 55