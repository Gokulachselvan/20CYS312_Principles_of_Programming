flatten :: [[Int]] -> [Int]
flatten a = [j | i<-a,j<-i]
main = print $ flatten [[1,2,3],[4,5],[6]]