reverseList :: [Int] -> [Int]
reverseList [x] = [x]
reverseList (a:b) = reverseList b ++ [a]
main = print $ reverseList [1,2,3,4,5]