lastElement :: [Int] -> Int
lastElement [a] = a
lastElement (q:r) = lastElement r
main = print $ lastElement [1,2,3,4,5]