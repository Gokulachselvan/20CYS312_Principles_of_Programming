listLength :: [Int] -> Int
listLength [x] = 1
listLength (a:b) = 1 + listLength b
main = print $ listLength [1,2,3,4,5,6]