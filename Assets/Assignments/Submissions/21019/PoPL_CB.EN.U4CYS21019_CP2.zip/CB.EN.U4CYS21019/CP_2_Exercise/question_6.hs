func :: [[a]] -> [[a]]
func [] = []
func ([]:_) = []
func m = [[r !! i | r <- m] | i <- [0..length (head m) - 1]]

main = print $ func [[1,2,3],[4,5,6],[7,8,9]]

--The output is returning the transpose of the input matrix